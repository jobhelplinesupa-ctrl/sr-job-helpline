SR JOB HELPLINE - FREE WEBSITE STARTER

Files:
- index.html: homepage with job cards
- jobs/boiler-operator.html: separate job page
- jobs/production-operator.html: separate job page

Important:
1. This is a static website starter. It is NOT published online yet.
2. Replace or verify phone number 9881585137 before publishing.
3. Job posts are examples; verify actual vacancies and salary with the employer.
4. To publish free, one simple route is GitHub Pages:
   - Sign in at https://github.com/
   - Create a public repository named sr-job-helpline
   - Upload all files while preserving the jobs folder
   - Open Settings > Pages
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save
   - Wait for GitHub to provide the published URL.
5. You can also use a static hosting provider that supports free static sites.
